// این فایل در صورت نیاز برای ارتباط با Telegram WebApp آماده است
console.log("Telegram WebApp integration ready");